import tkinter as tk
import sqlite3
import random
from typing import Self

class JokeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Joke App")
        self.root.geometry("400x300")

        # кнопка обновления
        self.refresh_img = tk.PhotoImage(file='./img/refresh.png')
        btn_refresh = tk.Button(self.root, bg='#d7d8e0', bd=0, image=self.refresh_img, command=self.show_joke)
        btn_refresh.pack(side=tk.LEFT)
        btn_refresh.pack(side=tk.TOP)
        # Создание текстового виджета
        self.text_joke = tk.Text(self.root, height=10, width=40)
        self.text_joke.pack()

        # Создание базы данных и таблицы
        self.conn = sqlite3.connect('jokes.db')
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS Jokes
                                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                                joke TEXT)''')

        # Наполнение базы данных анекдотами
        self.jokes = ["Попроси программиста проверить 10 строк кода, он найдёт 10 проблем.Попроси его проверить 500 строк, он скажет, что выглядит норм", 
                      "Если бы программисты были врачами, им бы говорили «У меня болит нога», а они отвечали «Ну не знаю, у меня такая же нога, а ничего не болит»", 
                      "Что такое <отложить> в программировании?Это такой магический тег, который вы можете использовать, когда не знаете, как правильно реализовать функцию.", 
                      "Если женщина — это шкатулка с секретом, то мужчина — сундук со сказками.",
                      "Женатому планировать отпуск очень легко: начальник говорит когда, жена — где."]
        for joke in self.jokes:
            self.cursor.execute("INSERT INTO Jokes (joke) VALUES (?)", (joke,))
        self.conn.commit()

    def show_joke(self):
        # Удаление предыдущей шутки, если она была
        self.text_joke.delete(0.0, tk.END)

        # Выбор случайной шутки из базы данных
        self.cursor.execute("SELECT joke FROM Jokes ORDER BY RANDOM() LIMIT 1")
        joke = self.cursor.fetchone()[0]

        # Вывод шутки в текстовый виджет
        self.text_joke.insert(0.0, joke)

root = tk.Tk()
app = JokeApp(root)
root.mainloop()